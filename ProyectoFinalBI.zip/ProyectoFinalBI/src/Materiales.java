public class Materiales {
	
	private int ID;
	private double  Precio, cantidad;
	private String Nombre ;
	
	//Constructor vac�o para eliminar materiales
	Materiales(){
		ID = this.getID();
		cantidad = 0.0;
		Precio = 0.0;
		Nombre = " ";
		
	}
	//Constructor para asignar valores de un arreglo
	Materiales(int miID, String miNombre, double miCantidad, double miPrecio){
		
		ID= miID;
		cantidad = miCantidad;
		Precio = miPrecio;
		Nombre = miNombre;
		
		
	}

	//Se asigna la cantidad del espacio del arreglo
	public void setCantidad(double miCantidad) {
		if(miCantidad >=0) {
			cantidad = miCantidad;
		}
		
	}
	//Se devuelve la cantidad del espacio del arreglo
	public double getCantidad() {
		return cantidad;
	}
	//Se asigna el precio del espacio del arreglo
	public void setPrecio(double miPrecio) {
		if (miPrecio >=0) {
			Precio = miPrecio;
		}
	}
	//Se devuelve el precio del espacio del arreglo
	public double getPrecio() {
		return Precio;
	}
	//Se asigna el ID del espacio del arreglo
	public void setID(int miID){
		if (miID >= 0){
			ID= miID;
		}
	}
	//Se asigna el nombre del espacio del arreglo
	public void setNombre(String miNombre) {
		Nombre = miNombre;
	}
	//Se devuelve el nombre del espacio del arreglo
	public String getNombre() {
		return Nombre;
	}
	//Se devuelve el ID del espacio del arreglo
	public int getID(){
		return ID;
	}
	
	//Se hace el token para guardar en el archivo de texto
	public String Tokenizer(){
		return (this.getID() + "," + this.getNombre() + "," + this.getCantidad()+ "," + this.getPrecio());
	}

}