import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class Menu extends JFrame {
// Nombramiento de variables para usar en el c�digo
	private JButton Pedidos, AgregarP, AgregarM, EditarP, EditarM, EliminarP, EliminarM, ListaP, ListaM, Guardar, Salir;
	private JLabel AgregarPL, AgregarPL2, Extra;
	
	private JLabel ID, Nombre, Cantidad, Precio, Tela, CantidadT, tip, tip1; 
	private JTextField NombreText, CantidadText, PrecioText, TelaText, CantidadTelaText, IDText, ColorText, IDProd, Cant;
	private JButton GuardarCambios, Revisar, Si, No;
	private JScrollPane Scroll;
	
	private JLabel IDP, NombreP, CantidadP, PrecioP, linea, linea2;
	
	
	private int id = 0, CantFin, idm = 0, IDARR, CantidadRevisar, IDRevisar;
	private double PrecioFin, CantMatFin;
	private String NombreFin, TelaFin, MaterialesCant, Text, TextTenemos, TextNecesitamos, dato, dato2;
	
	private JTextArea IDL, NombreL, PrecioL, CantidadTelaL, ColorTelaL, CantidadL, IDPedidos, PedidosDescripcion ;
	
	static Productos [] ArrProd = new Productos [1];
	static Materiales [] ArrMat = new Materiales[1];
	
	Productos valores1 = new Productos();
	Materiales valores2 = new Materiales();
	
	
	public static void main(String[] args) throws IOException {
		
		
		Menu Menu = new Menu();
		Menu.LeerArchivo();
		Menu.LeerArchivoMat();
		Menu.setVisible(true);
		

	}
	
	Menu() {
		//Ancho, Alto
				setSize(500, 500);
				//Titulo de la ventana
				setTitle("BASE DE DATOS");
				// libreria apra interactuar con la ventana
				// en este caso se utiliza para conocer el tama�o
				// de la pantalla y centrar la ventana
				Toolkit toolkit = getToolkit();
				Dimension size = toolkit.getScreenSize();
				setLocation(size. width/2 - getWidth()/2,
				size. height/2 - getHeight()/2);
				
				// Agregamos un panel
				JPanel panel = new JPanel();
				getContentPane().add(panel);
				panel.setLayout(new GridBagLayout());
				GridBagConstraints c = new GridBagConstraints();
				c. fill = GridBagConstraints. HORIZONTAL;
				
				JPanel botonesPnl = new JPanel();
				botonesPnl.setLayout(new GridBagLayout());
				
				Pedidos = new JButton ("Revisar");
				Pedidos.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					JFrame Pedidos = new JFrame();
					Pedidos.setSize(900, 900);
					Pedidos.setTitle("PEDIDOS");
					
					Toolkit tool=Pedidos.getToolkit();
					Dimension size= tool.getScreenSize();
					
					Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					Pedidos.getContentPane().add(display);
									
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					Border border = BorderFactory.createLineBorder(Color.BLACK);
					
					Scroll = new JScrollPane();
					Scroll.setBounds(200, 200, 200, 200);
					
					AgregarPL = new JLabel ("Productos:", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 0;
					botones.add(AgregarPL, c);
					
					// Productos
					// Se hacen los botones que ir�n en el panel
					
					ID = new JLabel("ID", JLabel.CENTER);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 1;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 1;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 1;
					botones.add(Cantidad, c);
					
					CantidadT = new JLabel("Cantidad Material", JLabel.CENTER);
					CantidadT.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 5;
					c. gridy = 1;
					botones.add(CantidadT, c);
					
					Tela = new JLabel("ID Material", JLabel.CENTER);
					Tela.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 4;
					c. gridy = 1;
					botones.add(Tela, c);
					
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 2;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 2;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 2;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 2;
					botones.add(CantidadL, c);
					
					CantidadTelaL = new JTextArea ();
					CantidadTelaL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 5;
					c. gridy = 2;
					botones.add(CantidadTelaL, c);
					
					ColorTelaL = new JTextArea ();
					ColorTelaL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 4;
					c. gridy = 2;
					botones.add(ColorTelaL, c);
					
					// Se hace la tabla en la que ir�n los datos de productos
					//Se nombran variables s�lo para esta tabla
					String IDpaso = "";
					String IDNombre = "";
					String IDPrecio = "";
					String IDCantidad = "";
					String IDCantMat = "";
					String IDMatProductos = "";
					//Se checan todos los valores del array ArrProd y se van imprimiendo en los String que se hicieron anteriormente
					for (int j = 1; j<ArrProd.length; j++) {
						if(ArrProd[j].getID() !=0) {
						IDpaso = IDpaso + ArrProd[j].getID() + " \n";
						IDL.setText(IDpaso);
						
						IDNombre = IDNombre + ArrProd[j].getNombre() + " \n";
						NombreL.setText(IDNombre);
						
						IDPrecio = IDPrecio + ArrProd[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecio);
						
						IDCantidad = IDCantidad + ArrProd[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidad);
						
						IDCantMat = IDCantMat + ArrProd[j].getCantidadMat() + " \n";
						CantidadTelaL.setText(IDCantMat);
						
						IDMatProductos = IDMatProductos + ArrProd[j].getIDMat() + " \n";
						ColorTelaL.setText(IDMatProductos);
						}
						
					}
					
					// Se cren los botones para Pedidos
					
					CantidadP= new JLabel ("-------- Consultar Material para el Pedido --------", JLabel.CENTER);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 6;
					c. gridx = 0;
					c. gridy = 3;
					botones.add(CantidadP, c);
					
					
					IDP = new JLabel ("ID Producto", JLabel.CENTER);
					IDP.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 4;
					botones.add(IDP, c);
					
					IDProd = new JTextField ();
					IDProd.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 4;
					botones.add(IDProd, c);
					IDProd.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
						char caracter = e.getKeyChar();

						// Verificar si la tecla pulsada no es un digito
						if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/)) {
						e.consume(); // ignorar el evento de teclado
						}
						}
						});
					
					NombreP =  new JLabel ("Cantidad de Producto(s)", JLabel.CENTER);
					NombreP.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 5;
					botones.add(NombreP, c);
					
					Cant = new JTextField ();
					Cant.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 5;
					botones.add(Cant, c);
					Cant.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/)) {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					
					
					
					PrecioP= new JLabel ("--------", JLabel.CENTER);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 6;
					c.gridheight = 1;
					c. gridx = 0;
					c. gridy = 7;
					botones.add(PrecioP, c);
					
					PedidosDescripcion = new JTextArea ();
					PedidosDescripcion.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 3;
					c.gridheight = 3;
					c. gridx = 3;
					c. gridy = 4;
					botones.add(PedidosDescripcion, c);
								
					
					// Materiales
					AgregarPL2 = new JLabel ("Materiales:", JLabel.CENTER);
					c.gridwidth = 1;
					c.gridheight = 1;
					c. gridx = 0;
					c. gridy = 8;
					botones.add(AgregarPL2, c);
					
					ID = new JLabel("ID", JLabel.CENTER);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 9;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 9;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 9;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad (En metros)", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 9;
					botones.add(Cantidad, c);
					
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 10;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 10;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 10;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 10;
					botones.add(CantidadL, c);
					
					//Se hace lo mismo que en el anterior, se nombran variables y se revisa el arreglo ArrMat para mostrar los valores en la tabla
					String IDPasoM = "", IDNombreM= "", IDPrecioM= "", IDCantidadM= "";
					for (int j = 1; j<ArrMat.length; j++) {
						if(ArrMat[j].getID() !=0) {
						IDPasoM = IDPasoM + ArrMat[j].getID() + " \n";
						IDL.setText(IDPasoM);
						
						IDNombreM = IDNombreM + ArrMat[j].getNombre() + " \n";
						NombreL.setText(IDNombreM);
						
						IDPrecioM = IDPrecioM + ArrMat[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecioM);
						
						IDCantidadM = IDCantidadM + ArrMat[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidadM);
						}
						
					}
					
					
					
					
					// Boton Guardar
					Guardar = new JButton ("Revisar");
					Guardar.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{
						//Se revisa si el ID del producto est� vac�o
						if (!(IDProd.getText().isEmpty()) && !(Cant.getText().isEmpty())) {
							IDRevisar = Integer.parseInt(IDProd.getText());
							CantidadRevisar = Integer.parseInt(Cant.getText());
							
							if (IDRevisar >= ArrProd.length || ArrProd[IDRevisar].getPrecio() == 0.0) {
								JFrame Pedidos = new JFrame();
								Pedidos.setSize(600, 300);
								Pedidos.setTitle("Revisar");
								
								Toolkit tool=Pedidos.getToolkit();
								Dimension size= tool.getScreenSize();
								
								Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
								GridBagConstraints c =new GridBagConstraints();
								JPanel display=new JPanel();
								display.setLayout(new GridBagLayout());
								Pedidos.getContentPane().add(display);
										
								//Se crea un nuevo panel
								JPanel botones =  new JPanel();
								botones.setLayout(new GridBagLayout());
								Border border = BorderFactory.createLineBorder(Color.BLACK);
								
								Scroll = new JScrollPane();
								Scroll.setBounds(200, 200, 200, 200);
								
								Text = "El ID seleccionado no existe o fue borrado, favor de revisar el dato.";
																				
								IDPedidos = new JTextArea (Text);
								c. fill = GridBagConstraints. HORIZONTAL;
								c.gridwidth = 1;
								c. gridx = 0;
								c. gridy = 0;
								botones.add(IDPedidos, c);
								
								
								//Se asigna todo a Scroll, para que aparezca la barra de scroll
								Scroll.setViewportView(botones);

								
								Pedidos.add(Scroll);
								Pedidos.setVisible(true);
									
								
							}
						}
						
						
						
						for (int i = 1; i<ArrProd.length; i++) {
							
							if (ArrProd[i].getID() == IDRevisar && ArrProd[i].getPrecio() != 0.0) {
								String linea = ArrProd[i].getIDMat();
								String linea2 = ArrProd[i].getCantidadMat();
									 StringTokenizer token = new StringTokenizer (linea, "/");
									 StringTokenizer token2 = new StringTokenizer (linea2, "/");
																	
										
										 //Se revisa si hay cantidad del producto que se requiere, si s� hay se hace un nuevo panel
										 if(ArrProd[IDRevisar].getCantidad() >= CantidadRevisar) {
											 
											 JFrame Pedidos = new JFrame();
												Pedidos.setSize(900, 900);
												Pedidos.setTitle("Revisar");
												
												Toolkit tool=Pedidos.getToolkit();
												Dimension size= tool.getScreenSize();
												
												Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
												GridBagConstraints c =new GridBagConstraints();
												JPanel display=new JPanel();
												display.setLayout(new GridBagLayout());
												Pedidos.getContentPane().add(display);
																
												JPanel botones =  new JPanel();
												botones.setLayout(new GridBagLayout());
												Border border = BorderFactory.createLineBorder(Color.BLACK);
																								
												AgregarPL = new JLabel ("Tenemos los productos necesarios, "
														+ " \n"
														+ "�Desea quitar los productos del inventario?", JLabel.CENTER);
												c. fill = GridBagConstraints. HORIZONTAL;
												c.gridwidth = 1;
												c. gridx = 0;
												c. gridy = 0;
												botones.add(AgregarPL, c);
												
												//Si se presiona el bot�n s�, entonces se quitar�n la cantidad de producto que se pidi�
												Si = new JButton ("Si");
												c. fill = GridBagConstraints. HORIZONTAL;
												Si.addActionListener(new ActionListener()
												{
													public void actionPerformed(ActionEvent event)
													{
														ArrProd[IDRevisar].setCantidad(ArrProd[IDRevisar].getCantidad() - CantidadRevisar);
														Pedidos.setVisible(false);
														Menu guardar = new Menu();
														try {
															//Se guarda el archivo de texto
															guardar.GuardarArchivoProd();
														} catch (IOException e) {
														}
													}});
												c.gridwidth = 1;
												c. gridx = 0;
												c. gridy = 1;
												botones.add(Si, c);
												
												//Si se presiona No, entonces no hace nada y cierra el panel
												No = new JButton ("No");
												No.addActionListener(new ActionListener()
												{
													public void actionPerformed(ActionEvent event)
													{
														//Se cierra el panel
														Pedidos.setVisible(false);
													}});
												c. fill = GridBagConstraints. HORIZONTAL;
												c.gridwidth = 1;
												c. gridx = 0;
												c. gridy = 2;
												botones.add(No, c);
												
												Pedidos.add(botones);
												Pedidos.setVisible(true);
											 
										 										
									 }
										 //Si faltan algunos materiales para hacer un producto se checan los materiales
									if(ArrProd[IDRevisar].getCantidad() < CantidadRevisar && ArrProd[IDRevisar].getCantidad() >= 0 ) {
										
										// ArrMat[Integer.parseInt(dato)].getCantidad() >= Integer.parseInt(dato2);
										
										JFrame Pedidos = new JFrame();
										Pedidos.setSize(600, 300);
										Pedidos.setTitle("Revisar");
										
										Toolkit tool=Pedidos.getToolkit();
										Dimension size= tool.getScreenSize();
										
										Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
										GridBagConstraints c =new GridBagConstraints();
										JPanel display=new JPanel();
										display.setLayout(new GridBagLayout());
										Pedidos.getContentPane().add(display);
														
										JPanel botones =  new JPanel();
										botones.setLayout(new GridBagLayout());
										Border border = BorderFactory.createLineBorder(Color.BLACK);
										
										Scroll = new JScrollPane();
										Scroll.setBounds(200, 200, 200, 200);
										
										TextTenemos =" \n" + "Tenemos estos materiales (Ya restando lo que se usar� para el producto)";
										TextNecesitamos ="\n" + "Necesitamos estos materiales para hacer los productos que faltan:";
										
										do {
											
											dato = token.nextToken(); // ID material
											dato2 = token2.nextToken(); // Cantidad Material
											
											//Se asignan los valores dependiendo de la disponibilidad del material
											if (ArrMat[Integer.parseInt(dato)].getCantidad() >= (Double.parseDouble(dato2) * CantidadRevisar)) {
												TextTenemos = TextTenemos + "\n"
											+ ArrMat[Integer.parseInt(dato)].getNombre() + ": " + 
														(ArrMat[Integer.parseInt(dato)].getCantidad() - (Double.parseDouble(dato2) * CantidadRevisar));
											
											}
											if (ArrMat[Integer.parseInt(dato)].getCantidad() < (Double.parseDouble(dato2)* CantidadRevisar)) {
												TextNecesitamos =TextNecesitamos
											+ " \n" + ArrMat[Integer.parseInt(dato)].getNombre()
														+ ": " + ((Double.parseDouble(dato2) * CantidadRevisar) - ArrMat[Integer.parseInt(dato)].getCantidad());
												
											}
											
											
											
											
										}while (token.hasMoreTokens());
										//Si hay productos completos, se muestran a continuaci�n
										Text = ("Tenemos: "  + ArrProd[IDRevisar].getCantidad() +  " productos, nos faltan: "
												+ (CantidadRevisar - ArrProd[IDRevisar].getCantidad())
												+ " \n"
												+ " \n") + TextTenemos +  " \n" + " \n" +TextNecesitamos;
																						
										IDPedidos = new JTextArea (Text);
										c. fill = GridBagConstraints. HORIZONTAL;
										c.gridwidth = 1;
										c. gridx = 0;
										c. gridy = 0;
										botones.add(IDPedidos, c);
										
										
										
										Scroll.setViewportView(botones);

										
										Pedidos.add(Scroll);
										Pedidos.setVisible(true);
												
									}
									
									
									
									
									
							}
							
						}
						
						
						//Se revisan si faltan datos solicitados
						if (IDProd.getText().isEmpty() || Cant.getText().isEmpty()) {
							JFrame Pedidos = new JFrame();
							Pedidos.setSize(600, 300);
							Pedidos.setTitle("Revisar");
							
							Toolkit tool=Pedidos.getToolkit();
							Dimension size= tool.getScreenSize();
							
							Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
							GridBagConstraints c =new GridBagConstraints();
							JPanel display=new JPanel();
							display.setLayout(new GridBagLayout());
							Pedidos.getContentPane().add(display);
											
							JPanel botones =  new JPanel();
							botones.setLayout(new GridBagLayout());
							Border border = BorderFactory.createLineBorder(Color.BLACK);
							
							Scroll = new JScrollPane();
							Scroll.setBounds(200, 200, 200, 200);
							
							Text = "Faltan datos, favor de introducirlos";
																			
							IDPedidos = new JTextArea (Text);
							c. fill = GridBagConstraints. HORIZONTAL;
							c.gridwidth = 1;
							c. gridx = 0;
							c. gridy = 0;
							botones.add(IDPedidos, c);
							
							
							
							Scroll.setViewportView(botones);

							
							Pedidos.add(Scroll);
							Pedidos.setVisible(true);
								
							
						}
						
						
						
					}});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c.gridheight = 3;
					c. gridx = 2;
					c. gridy = 4;
					botones.add(Guardar, c);
					
					Scroll.setViewportView(botones);

										
					Pedidos.add(Scroll);
					Pedidos.setVisible(true);
					
					
				}});
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 2;
				c. gridx = 0;
				c. gridy = 0;
				panel.add(Pedidos, c);

				//Se hace un bot�n nuevo, agregar producto
				AgregarP = new JButton ("Agregar Producto");
				AgregarP.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					//Se hace un frame y un panel nuevo
					JFrame AgregarProd = new JFrame();
					AgregarProd.setSize(1000, 600);
					AgregarProd.setTitle("AGREGAR PRODUCTO");
					
					Toolkit tool=AgregarProd.getToolkit();
					Dimension size= tool.getScreenSize();
					
					AgregarProd.setLocation(size.width/2- AgregarProd.getWidth()/2 +50, size.height/2 - AgregarProd.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					AgregarProd.getContentPane().add(display);
					
					Scroll = new JScrollPane();
					Scroll.setBounds(200, 200, 200, 200);
					
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					 id = ArrProd.length - 1;
					 id++;
					//Se hacen nuevos botones para el panel
					AgregarPL = new JLabel ("AGREGAR PRODUCTO", JLabel.CENTER);
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 0;
					botones.add(AgregarPL, c);
					
					ID = new JLabel ("ID: " + id, JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(ID, c);
					
					NombreText = new JTextField();
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 2;
					botones.add(NombreText, c);					
					
					Nombre = new JLabel ("Nombre ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 2;
					botones.add(Nombre, c);
					
					Cantidad = new JLabel ("Cantidad ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 3;
					botones.add(Cantidad, c);
					
					CantidadText = new JTextField();
					CantidadText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/)) {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 3;
					botones.add(CantidadText, c);
					
					Precio = new JLabel ("Precio ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 4;
					botones.add(Precio, c);
					
					PrecioText = new JTextField();
					PrecioText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='.') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 4;
					botones.add(PrecioText, c);
					
					
					Tela = new JLabel ("ID Mat ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 5;
					botones.add(Tela, c);
					
					TelaText = new JTextField(); // Aqui van ID de materiales
					TelaText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='/') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 5;
					botones.add(TelaText, c);
					
					tip = new JLabel("Si son varios materiales escribir con / Ej. 1/13/15");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 5;
					botones.add(tip, c);
					
					CantidadT = new JLabel ("Cantidad Mat ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 6;
					botones.add(CantidadT, c);
					
					CantidadTelaText = new JTextField();
					CantidadTelaText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='/'  && caracter !='.') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 6;
					botones.add(CantidadTelaText, c);
					
					//Se explica c�mo funciona el label
					tip1 = new JLabel("Si son varias cantidades (por varios materiales) escribir con / Ej. 3/18.56/12. Escribir en el orden de los materiales");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 6;
					botones.add(tip1, c);
					
					Extra = new JLabel("Lista de Materiales:");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 4;
					c. gridx = 0;
					c. gridy = 8;
					botones.add(Extra, c);
					
					ID = new JLabel("ID", JLabel.CENTER);
					Border border = BorderFactory.createLineBorder(Color.BLACK);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 9;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 9;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 9;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 9;
					botones.add(Cantidad, c);
					
					//Se agrega la tabla
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 10;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 10;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 10;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 10;
					botones.add(CantidadL, c);
					
					//Se le da los valores y variables a la tabla, para llenarla con el Arreglo de Materiales
					String IDpaso = "";
					String IDNombre = "";
					String IDPrecio = "";
					String IDCantidad = "";
					for (int j = 1; j<ArrMat.length; j++) {
						if(ArrMat[j].getID() !=0) {
						IDpaso = IDpaso + ArrMat[j].getID() + " \n";
						IDL.setText(IDpaso);
						
						IDNombre = IDNombre + ArrMat[j].getNombre() + " \n";
						NombreL.setText(IDNombre);
						
						IDPrecio = IDPrecio + ArrMat[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecio);
						
						IDCantidad = IDCantidad + ArrMat[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidad);
						}
						
					}
					
					//Se guardan los cambios
					GuardarCambios = new JButton ("Guardar Cambios");
					GuardarCambios.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{
						//Se revisan los datos
						if (NombreText.getText().isEmpty() || CantidadText.getText().isEmpty() || PrecioText.getText().isEmpty() || CantidadTelaText.getText().isEmpty() || TelaText.getText().isEmpty()) {
							JFrame Pedidos = new JFrame();
							Pedidos.setSize(600, 300);
							Pedidos.setTitle("Revisar");
							
							Toolkit tool=Pedidos.getToolkit();
							Dimension size= tool.getScreenSize();
							
							Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
							GridBagConstraints c =new GridBagConstraints();
							JPanel display=new JPanel();
							display.setLayout(new GridBagLayout());
							Pedidos.getContentPane().add(display);
											
							JPanel botones =  new JPanel();
							botones.setLayout(new GridBagLayout());
							Border border = BorderFactory.createLineBorder(Color.BLACK);
							
							Scroll = new JScrollPane();
							Scroll.setBounds(200, 200, 200, 200);
							
							//Si faltan datos aparece este mensaje
							Text = "Faltan datos, favor de introducirlos";
																			
							IDPedidos = new JTextArea (Text);
							c. fill = GridBagConstraints. HORIZONTAL;
							c.gridwidth = 1;
							c. gridx = 0;
							c. gridy = 0;
							botones.add(IDPedidos, c);
							
							
							
							Scroll.setViewportView(botones);

							
							Pedidos.add(Scroll);
							Pedidos.setVisible(true);
								
							
						}else {
						
							//Si no faltan datos se usan los sets y gets
						NombreFin = NombreText.getText();
						NombreFin = NombreFin.toUpperCase();
						CantFin = Integer.parseInt(CantidadText.getText());
						PrecioFin = Double.parseDouble(PrecioText.getText());
						MaterialesCant = CantidadTelaText.getText(); // CantidadMateriales
						TelaFin = TelaText.getText(); // Aqui van los ID de Materiales
						
						
						
						Productos valores = new Productos (id, CantFin, MaterialesCant, PrecioFin, NombreFin, TelaFin);
						ArrProd[0] = valores;
						
						//Se a�ade un nuevo valor al arreglo de ArrProd
						ArrProd = addItem(ArrProd, valores);
						
						Menu guardar = new Menu();
						
						try {
							//Se guarda el archivo
							guardar.GuardarArchivoProd();
						} catch (IOException e) {
						}
						AgregarProd.setVisible(false);
						}
						
						
					} });
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 7;
					botones.add(GuardarCambios, c);
					
					Scroll.setViewportView(botones);
					
					AgregarProd.add(Scroll);
					AgregarProd.setVisible(true);
				
				} });
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 1;
				c. gridx = 0;
				c. gridy = 1;
				panel.add(AgregarP, c);
				
				//Nuevo bot�n, Aregar Material
				AgregarM = new JButton ("Agregar Material");
				AgregarM.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					JFrame AgregarMaterial = new JFrame();
					AgregarMaterial.setSize(600, 600);
					AgregarMaterial.setTitle("AGREGAR MATERIAL");
					
					Toolkit tool=AgregarMaterial.getToolkit();
					Dimension size= tool.getScreenSize();
					
					AgregarMaterial.setLocation(size.width/2- AgregarMaterial.getWidth()/2 +50, size.height/2 - AgregarMaterial.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					AgregarMaterial.getContentPane().add(display);
					
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					
					Scroll = new JScrollPane();
					Scroll.setBounds(200, 200, 200, 200);
					
					Scroll.setViewportView(botones);
					
					AgregarMaterial.add(Scroll);
					AgregarMaterial.setVisible(true);
					idm = ArrMat.length-1;
					idm++;
					
					//Se hacen los labels y textfields
					AgregarPL = new JLabel ("AGREGAR MATERIAL", JLabel.CENTER);
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 0;
					botones.add(AgregarPL, c);
					
					ID = new JLabel ("ID: " + idm, JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(ID, c);
					
					NombreText = new JTextField();
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 2;
					botones.add(NombreText, c);
					
					Nombre = new JLabel ("Nombre ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 2;
					botones.add(Nombre, c);
					
					Cantidad = new JLabel ("Cantidad ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 3;
					botones.add(Cantidad, c);
					
					CantidadText = new JTextField();
					CantidadText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='.') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 3;
					botones.add(CantidadText, c);
					
					Precio = new JLabel ("Precio ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 4;
					botones.add(Precio, c);
					
					PrecioText = new JTextField();
					PrecioText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='.') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 4;
					botones.add(PrecioText, c);
					
					
					//Se guardan los cambios
					GuardarCambios = new JButton ("Guardar Cambios");
					GuardarCambios.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{			
						//Se revisan los datos
						if (NombreText.getText().isEmpty() || CantidadText.getText().isEmpty() || PrecioText.getText().isEmpty()) {
							JFrame Pedidos = new JFrame();
							Pedidos.setSize(600, 300);
							Pedidos.setTitle("Revisar");
							
							Toolkit tool=Pedidos.getToolkit();
							Dimension size= tool.getScreenSize();
							
							Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
							GridBagConstraints c =new GridBagConstraints();
							JPanel display=new JPanel();
							display.setLayout(new GridBagLayout());
							Pedidos.getContentPane().add(display);
											
							JPanel botones =  new JPanel();
							botones.setLayout(new GridBagLayout());
							Border border = BorderFactory.createLineBorder(Color.BLACK);
							
							Scroll = new JScrollPane();
							Scroll.setBounds(200, 200, 200, 200);
							
							//Si faltan datos aparece este mensaje
							Text = "Faltan datos, favor de introducirlos";
																			
							IDPedidos = new JTextArea (Text);
							c. fill = GridBagConstraints. HORIZONTAL;
							c.gridwidth = 1;
							c. gridx = 0;
							c. gridy = 0;
							botones.add(IDPedidos, c);
							
							
							
							Scroll.setViewportView(botones);

							
							Pedidos.add(Scroll);
							Pedidos.setVisible(true);
								
							
						}else {
						
							//Si no faltan datos se asignan los datos a sus sets
						NombreFin = NombreText.getText();
						NombreFin = NombreFin.toUpperCase();
						CantMatFin = Double.parseDouble(CantidadText.getText());
						PrecioFin = Double.parseDouble(PrecioText.getText());						
						
						
						Materiales valoresMat = new Materiales (idm, NombreFin, CantMatFin, PrecioFin);
						ArrMat[0] = valoresMat;
						
						ArrMat = addItemMat(ArrMat, valoresMat);
						
						Menu GuardarMat = new Menu();
						try {
							//Se guarda el archivo
							GuardarMat.GuardarArchivoMat();
						} catch (IOException e) {

						}
						
						AgregarMaterial.setVisible(false);
						}
						
						
					} });
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 7;
					botones.add(GuardarCambios, c);
					
				} });
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 1;
				c. gridx = 1;
				c. gridy = 1;
				panel.add(AgregarM, c);
				
				//Nuevo bot�n Editar Producto
				EditarP = new JButton ("Editar Producto");
				EditarP.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					//Se hace un nuevo Frame y Panel
					JFrame EditarProducto = new JFrame();
					EditarProducto.setSize(600, 600);
					EditarProducto.setTitle("EDITAR PRODUCTO");
					
					Toolkit tool=EditarProducto.getToolkit();
					Dimension size= tool.getScreenSize();
					
					EditarProducto.setLocation(size.width/2- EditarProducto.getWidth()/2 +50, size.height/2 - EditarProducto.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					EditarProducto.getContentPane().add(display);
					
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					
					EditarProducto.add(botones);
					EditarProducto.setVisible(true);
					
					
					//Se asignan los labels y textfields
					AgregarPL = new JLabel ("EDITAR PRODUCTO", JLabel.CENTER);
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 0;
					botones.add(AgregarPL, c);
					
					ID = new JLabel ("ID: ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(ID, c);
					
					//Nuevo bot�n, revisar, para checar si existe el ID
					Revisar = new JButton (" Revisar ");
					Revisar.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{
						int RevisarID = 0;
						String  Cantidad;
						
						RevisarID = Integer.parseInt(IDText.getText());
						
						//Se revisa si existe el ID
						if (RevisarID >= ArrProd.length) {
							JFrame Pedidos = new JFrame();
							Pedidos.setSize(600, 300);
							Pedidos.setTitle("Revisar");
							
							Toolkit tool=Pedidos.getToolkit();
							Dimension size= tool.getScreenSize();
							
							Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
							GridBagConstraints c =new GridBagConstraints();
							JPanel display=new JPanel();
							display.setLayout(new GridBagLayout());
							Pedidos.getContentPane().add(display);
											
							JPanel botones =  new JPanel();
							botones.setLayout(new GridBagLayout());
							Border border = BorderFactory.createLineBorder(Color.BLACK);
							
							Scroll = new JScrollPane();
							Scroll.setBounds(200, 200, 200, 200);
							
							//Si no existe aparece este mensaje
							Text = "El ID seleccionado no existe o fue borrado, favor de revisar el dato.";
																			
							IDPedidos = new JTextArea (Text);
							c. fill = GridBagConstraints. HORIZONTAL;
							c.gridwidth = 1;
							c. gridx = 0;
							c. gridy = 0;
							botones.add(IDPedidos, c);
							
							
							
							Scroll.setViewportView(botones);

							
							Pedidos.add(Scroll);
							Pedidos.setVisible(true);
								
							
						}else {
						//Si existe se asignan los valores
						for (int i =0; i<ArrProd.length; i++) {
							if (RevisarID == ArrProd[i].getID()) {
								NombreText.setText(ArrProd[i].getNombre());
								Cantidad = "" + ArrProd[i].getCantidad();
								CantidadText.setText(Cantidad);
								Cantidad = "" + ArrProd[i].getPrecio();
								PrecioText.setText(Cantidad);
								ColorText.setText(ArrProd[i].getIDMat());
								Cantidad = "" + ArrProd[i].getCantidadMat();
								CantidadTelaText.setText(Cantidad);
								
							}
						}
						
						}
						
					}});
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 1;
					botones.add(Revisar, c);
					
					IDText = new JTextField();
					IDText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/)) {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 1;
					botones.add(IDText, c);
					
					NombreText = new JTextField();
					NombreText.setText("-");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 2;
					botones.add(NombreText, c);
					
					Nombre = new JLabel ("Nombre ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 2;
					botones.add(Nombre, c);
					
					Cantidad = new JLabel ("Cantidad ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 3;
					botones.add(Cantidad, c);
					
					CantidadText = new JTextField();
					CantidadText.setText("0");
					CantidadText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='.') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 3;
					botones.add(CantidadText, c);
					
					Precio = new JLabel ("Precio ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 4;
					botones.add(Precio, c);
					
					PrecioText = new JTextField();
					PrecioText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='.') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					PrecioText.setText("0");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 4;
					botones.add(PrecioText, c);
					
					CantidadT = new JLabel ("Cantidad Mat ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 6;
					botones.add(CantidadT, c);
					
					CantidadTelaText = new JTextField();
					CantidadTelaText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='/') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					CantidadTelaText.setText("-");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 6;
					botones.add(CantidadTelaText, c);
					
					Tela = new JLabel ("ID Mat ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 5;
					botones.add(Tela, c);
					
					ColorText = new JTextField();
					ColorText.setText("-");
					ColorText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='/') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 5;
					botones.add(ColorText, c);
					
					linea = new JLabel(" --------------------------------------- ", JLabel.CENTER);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 6;
					c. gridx = 0;
					c. gridy = 8;
					botones.add(linea, c);
					
					linea2 = new JLabel(" Lista de Productos ", JLabel.CENTER);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 6;
					c. gridx = 0;
					c. gridy = 9;
					botones.add(linea2, c);
					
					ID = new JLabel("ID", JLabel.CENTER);
					Border border = BorderFactory.createLineBorder(Color.BLACK);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 10;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 10;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 10;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 10;
					botones.add(Cantidad, c);
					
					CantidadT = new JLabel("Cantidad del Material", JLabel.CENTER);
					CantidadT.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 5;
					c. gridy = 10;
					botones.add(CantidadT, c);
					
					Tela = new JLabel("IDMaterial", JLabel.CENTER);
					Tela.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 4;
					c. gridy = 10;
					botones.add(Tela, c);
					
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 11;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 11;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 11;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 11;
					botones.add(CantidadL, c);
					
					CantidadTelaL = new JTextArea ();
					CantidadTelaL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 5;
					c. gridy = 11;
					botones.add(CantidadTelaL, c);
					
					ColorTelaL = new JTextArea ();
					ColorTelaL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 4;
					c. gridy = 11;
					botones.add(ColorTelaL, c);
					
					//Se hace una tabla como se hizo anteriormente
					String IDpaso = "";
					String IDNombre = "";
					String IDPrecio = "";
					String IDCantidad = "";
					String IDColorTela = "";
					String IDCantidadTela = "";
					for (int j = 1; j<ArrProd.length; j++) {
						if(ArrProd[j].getID() !=0) {
						IDpaso = IDpaso + ArrProd[j].getID() + " \n";
						IDL.setText(IDpaso);
						
						IDNombre = IDNombre + ArrProd[j].getNombre() + " \n";
						NombreL.setText(IDNombre);
						
						IDPrecio = IDPrecio + ArrProd[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecio);
						
						IDCantidad = IDCantidad + ArrProd[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidad);
						
						IDCantidadTela = IDCantidadTela + ArrProd[j].getCantidadMat() + " \n";
						CantidadTelaL.setText(IDCantidadTela);
						
						IDColorTela = IDColorTela + ArrProd[j].getIDMat() + " \n";
						ColorTelaL.setText(IDColorTela);
						}
						
					}	
					
					//Se guardan los cambios que se editaron
					GuardarCambios = new JButton ("Guardar Cambios");
					GuardarCambios.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{
						
						IDARR = Integer.parseInt(IDText.getText());
						for(int j=1; j<ArrProd.length; j++) {
							if(IDARR == ArrProd[j].getID()) {
								
								NombreFin = NombreText.getText();
								if(!(NombreFin.equals("-"))) {
								NombreFin = NombreFin.toUpperCase();
								ArrProd[j].setNombre(NombreFin);
								}
								
								CantFin = Integer.parseInt(CantidadText.getText());
								if (!(CantFin<=0)) {
								ArrProd[j].setCantidad(CantFin);
								}
								PrecioFin = Double.parseDouble(PrecioText.getText());
								if(!(PrecioFin<=0)) {
								ArrProd[j].setPrecio(PrecioFin);
								}
								
								MaterialesCant = CantidadTelaText.getText();
								ArrProd[j].setCantidadMat(MaterialesCant);
								
								
								TelaFin = ColorText.getText();
								ArrProd[j].setIDMat(TelaFin);
								
								
								Menu guardar = new Menu();
								
								try {
									guardar.GuardarArchivoProd();
								} catch (IOException e) {
								}
						
						
						EditarProducto.setVisible(false);
							}
						}
						
					} });
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 7;
					botones.add(GuardarCambios, c);
					
				} });
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 1;
				c. gridx = 0;
				c. gridy = 2;
				panel.add(EditarP, c);
				
				//Nuevo bot�n, Editar Material
				EditarM = new JButton ("Editar Material");
				EditarM.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					//Se hace un nuevo Frame y Panel
					JFrame EditarMaterial = new JFrame();
					EditarMaterial.setSize(600, 600);
					EditarMaterial.setTitle("EDITAR MATERIAL");
					
					Toolkit tool=EditarMaterial.getToolkit();
					Dimension size= tool.getScreenSize();
					
					EditarMaterial.setLocation(size.width/2- EditarMaterial.getWidth()/2 +50, size.height/2 - EditarMaterial.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					EditarMaterial.getContentPane().add(display);
					
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					
					EditarMaterial.add(botones);
					EditarMaterial.setVisible(true);
					
					//Nuevos labels y TextFields
					AgregarPL = new JLabel ("EDITAR MATERIAL", JLabel.CENTER);
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 0;
					botones.add(AgregarPL, c);
					
					ID = new JLabel ("ID: ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(ID, c);
					
					IDText = new JTextField();
					IDText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/)) {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 1;
					botones.add(IDText, c);
					
					//Bot�n revisar, igual que en Editar Producto
					Revisar = new JButton (" Revisar ");
					Revisar.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{
						int RevisarID = 0;
						String  Cantidad;
						
						RevisarID = Integer.parseInt(IDText.getText());
						
						if (RevisarID >= ArrMat.length) {
							JFrame Pedidos = new JFrame();
							Pedidos.setSize(600, 300);
							Pedidos.setTitle("Revisar");
							
							Toolkit tool=Pedidos.getToolkit();
							Dimension size= tool.getScreenSize();
							
							Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
							GridBagConstraints c =new GridBagConstraints();
							JPanel display=new JPanel();
							display.setLayout(new GridBagLayout());
							Pedidos.getContentPane().add(display);
											
							JPanel botones =  new JPanel();
							botones.setLayout(new GridBagLayout());
							Border border = BorderFactory.createLineBorder(Color.BLACK);
							
							Scroll = new JScrollPane();
							Scroll.setBounds(200, 200, 200, 200);
							
							//Si no existe el ID aparece este mensaje
							Text = "El ID seleccionado no existe o fue borrado, favor de revisar el dato.";
																			
							IDPedidos = new JTextArea (Text);
							c. fill = GridBagConstraints. HORIZONTAL;
							c.gridwidth = 1;
							c. gridx = 0;
							c. gridy = 0;
							botones.add(IDPedidos, c);
							
							
							
							Scroll.setViewportView(botones);

							
							Pedidos.add(Scroll);
							Pedidos.setVisible(true);
								
							
						}else {
						//Si s� existe el ID se asignan los valores
						for (int i =0; i<ArrMat.length; i++) {
							if (RevisarID == ArrMat[i].getID()) {
								NombreText.setText(ArrMat[i].getNombre());
								Cantidad = "" + ArrMat[i].getCantidad();
								CantidadText.setText(Cantidad);
								Cantidad = "" + ArrMat[i].getPrecio();
								PrecioText.setText(Cantidad);
								
							}
						}
						
						}
						
					}});
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 1;
					botones.add(Revisar, c);
					
					NombreText = new JTextField();
					NombreText.setText("-");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 2;
					botones.add(NombreText, c);
					
					Nombre = new JLabel ("Nombre ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 2;
					botones.add(Nombre, c);
					
					Cantidad = new JLabel ("Cantidad ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 3;
					botones.add(Cantidad, c);
					
					CantidadText = new JTextField();
					CantidadText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='.') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					CantidadText.setText("0");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 3;
					botones.add(CantidadText, c);
					
					Precio = new JLabel ("Precio ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 4;
					botones.add(Precio, c);
					
					PrecioText = new JTextField();
					PrecioText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) && caracter !='.') {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					PrecioText.setText("0");
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 4;
					botones.add(PrecioText, c);
					
					linea = new JLabel (" ------------------------------------------- ", JLabel.CENTER);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 4;
					c. gridx = 0;
					c. gridy = 6;
					botones.add(linea, c);
					
					Extra = new JLabel("Lista de Materiales", JLabel.CENTER);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 4;
					c. gridx = 0;
					c. gridy = 8;
					botones.add(Extra, c);
					
					ID = new JLabel("ID", JLabel.CENTER);
					Border border = BorderFactory.createLineBorder(Color.BLACK);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 9;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 9;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 9;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 9;
					botones.add(Cantidad, c);
					
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 10;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 10;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 10;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 10;
					botones.add(CantidadL, c);
					
					//Se hace una tabla con los valores
					String IDpaso = "";
					String IDNombre = "";
					String IDPrecio = "";
					String IDCantidad = "";
					for (int j = 1; j<ArrMat.length; j++) {
						if(ArrMat[j].getID() !=0) {
						IDpaso = IDpaso + ArrMat[j].getID() + " \n";
						IDL.setText(IDpaso);
						
						IDNombre = IDNombre + ArrMat[j].getNombre() + " \n";
						NombreL.setText(IDNombre);
						
						IDPrecio = IDPrecio + ArrMat[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecio);
						
						IDCantidad = IDCantidad + ArrMat[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidad);
						}
						
					}
					
					
					//Se guardan los cambios
					GuardarCambios = new JButton ("Guardar Cambios");
					GuardarCambios.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{
						//Se asignan los valores
						IDARR = Integer.parseInt(IDText.getText());
						for(int j=1; j<ArrMat.length; j++) {
							if(IDARR == ArrMat[j].getID()) {
								
								NombreFin = NombreText.getText();
								if(!(NombreFin.equals("-"))) {
								NombreFin = NombreFin.toUpperCase();
								ArrMat[j].setNombre(NombreFin);
								}
								
								CantMatFin = Double.parseDouble(CantidadText.getText());
								if (!(CantMatFin<=0)) {
									ArrMat[j].setCantidad(CantMatFin);
								}
								PrecioFin = Double.parseDouble(PrecioText.getText());
								if(!(PrecioFin<=0)) {
									ArrMat[j].setPrecio(PrecioFin);
								}								
							}
						}
						
						Menu guardar = new Menu();
						
						try {
							//Se guarda el archivo
							guardar.GuardarArchivoMat();
						} catch (IOException e) {
						}
								
						EditarMaterial.setVisible(false);
						
						
					} });
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 5;
					botones.add(GuardarCambios, c);
					
				} });
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 1;
				c. gridx = 1;
				c. gridy = 2;
				panel.add(EditarM, c);
				
				//Nuevo bot�n, Eliminar Producto
				EliminarP = new JButton ("Eliminar Producto");
				EliminarP.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					//Se crea un nuevo Frame y un nuevo Panel
					JFrame EliminarProducto = new JFrame();
					EliminarProducto.setSize(600, 600);
					EliminarProducto.setTitle("ELIMINAR PRODUCTO");
					
					Toolkit tool=EliminarProducto.getToolkit();
					Dimension size= tool.getScreenSize();
					
					EliminarProducto.setLocation(size.width/2- EliminarProducto.getWidth()/2 +50, size.height/2 - EliminarProducto.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					EliminarProducto.getContentPane().add(display);
					
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					
					Scroll = new JScrollPane();
					Scroll.setBounds(200, 200, 200, 200);
					
					Scroll.setViewportView(botones);

								
					EliminarProducto.add(Scroll);
					EliminarProducto.setVisible(true);
					
					//Se asignan los labels y TextAreas
					ID = new JLabel ("ID: ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(ID, c);
					
					IDText = new JTextField();
					IDText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/) ) {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 1;
					botones.add(IDText, c);
					
					ID = new JLabel("ID", JLabel.CENTER);
					Border border = BorderFactory.createLineBorder(Color.BLACK);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 4;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 4;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 4;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 4;
					botones.add(Cantidad, c);
					
					CantidadT = new JLabel("Cantidad del Material", JLabel.CENTER);
					CantidadT.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 5;
					c. gridy = 4;
					botones.add(CantidadT, c);
					
					Tela = new JLabel("IDMaterial", JLabel.CENTER);
					Tela.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 4;
					c. gridy = 4;
					botones.add(Tela, c);
					
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 5;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 5;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 5;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 5;
					botones.add(CantidadL, c);
					
					CantidadTelaL = new JTextArea ();
					CantidadTelaL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 5;
					c. gridy = 5;
					botones.add(CantidadTelaL, c);
					
					ColorTelaL = new JTextArea ();
					ColorTelaL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 4;
					c. gridy = 5;
					botones.add(ColorTelaL, c);
					
					//Se hace la tabla
					String IDpaso = "";
					String IDNombre = "";
					String IDPrecio = "";
					String IDCantidad = "";
					String IDColorTela = "";
					String IDCantidadTela = "";
					for (int j = 1; j<ArrProd.length; j++) {
						if(ArrProd[j].getID() !=0) {
						IDpaso = IDpaso + ArrProd[j].getID() + " \n";
						IDL.setText(IDpaso);
						
						IDNombre = IDNombre + ArrProd[j].getNombre() + " \n";
						NombreL.setText(IDNombre);
						
						IDPrecio = IDPrecio + ArrProd[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecio);
						
						IDCantidad = IDCantidad + ArrProd[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidad);
						
						IDCantidadTela = IDCantidadTela + ArrProd[j].getCantidadMat() + " \n";
						CantidadTelaL.setText(IDCantidadTela);
						
						IDColorTela = IDColorTela + ArrProd[j].getIDMat() + " \n";
						ColorTelaL.setText(IDColorTela);
						}
						
					}				
					
					//Se guardan los cambios
					GuardarCambios = new JButton ("ELIMINAR PRODUCTO");
					GuardarCambios.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{
						IDARR = Integer.parseInt(IDText.getText());
						//Se revisa si existe el ID
						if (IDARR >= ArrProd.length) {
							JFrame Pedidos = new JFrame();
							Pedidos.setSize(600, 300);
							Pedidos.setTitle("Revisar");
							
							Toolkit tool=Pedidos.getToolkit();
							Dimension size= tool.getScreenSize();
							
							Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
							GridBagConstraints c =new GridBagConstraints();
							JPanel display=new JPanel();
							display.setLayout(new GridBagLayout());
							Pedidos.getContentPane().add(display);
											
							JPanel botones =  new JPanel();
							botones.setLayout(new GridBagLayout());
							Border border = BorderFactory.createLineBorder(Color.BLACK);
							
							Scroll = new JScrollPane();
							Scroll.setBounds(200, 200, 200, 200);
							//Si no existe aparece este mensaje
							Text = "El ID seleccionado no existe o fue borrado, favor de revisar el dato.";
																			
							IDPedidos = new JTextArea (Text);
							c. fill = GridBagConstraints. HORIZONTAL;
							c.gridwidth = 1;
							c. gridx = 0;
							c. gridy = 0;
							botones.add(IDPedidos, c);
							
							
							
							Scroll.setViewportView(botones);

							
							Pedidos.add(Scroll);
							Pedidos.setVisible(true);
								
							
						}else {
						//Si s� existe se guarda
						for(int j=0; j<ArrProd.length; j++) {
							if(ArrProd[j].getID() == IDARR) {
								ArrProd[j]=valores1;
							}
							
							Menu guardar = new Menu ();
							try {
								//Se vuelve a guardar el archivo
								guardar.GuardarArchivoProd();
							} catch (IOException e) {
							}
						}
											
						EliminarProducto.setVisible(false);
						
						}
						
					} });
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 2;
					botones.add(GuardarCambios, c);					
				} });					
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 1;
				c. gridx = 0;
				c. gridy = 3;
				panel.add(EliminarP, c);
				
				//Nuevo bot�n, eliminar material
				EliminarM = new JButton ("Eliminar Material");
				EliminarM.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					//Se crea un nuevo Frame y Display
					JFrame EliminarMaterial = new JFrame();
					EliminarMaterial.setSize(600, 600);
					EliminarMaterial.setTitle("ELIMINAR MATERIAL");
					
					Toolkit tool=EliminarMaterial.getToolkit();
					Dimension size= tool.getScreenSize();
					
					EliminarMaterial.setLocation(size.width/2- EliminarMaterial.getWidth()/2 +50, size.height/2 - EliminarMaterial.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					EliminarMaterial.getContentPane().add(display);
					
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					
					Scroll = new JScrollPane();
					Scroll.setBounds(200, 200, 200, 200);
					
					Scroll.setViewportView(botones);
								
					EliminarMaterial.add(Scroll);
					EliminarMaterial.setVisible(true);
					
					//Se hacen nuevos Labels y TextFields
					ID = new JLabel ("ID: ", JLabel.CENTER);
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(ID, c);
					
					IDText = new JTextField();
					IDText.addKeyListener(new KeyAdapter() {
						public void keyTyped(KeyEvent e) {
							char caracter = e.getKeyChar();

							// Verificar si la tecla pulsada no es un digito
							if (((caracter < '0') || (caracter > '9')) && (caracter != '\b' /*corresponde a BACK_SPACE*/)) {
							e.consume(); // ignorar el evento de teclado
							}
							}
							});
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 1;
					botones.add(IDText, c);
								
								
					ID = new JLabel("ID", JLabel.CENTER);
					Border border = BorderFactory.createLineBorder(Color.BLACK);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 3;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 3;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 3;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 3;
					botones.add(Cantidad, c);
					
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 4;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 4;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 4;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 4;
					botones.add(CantidadL, c);
					
					//Se crea la tabla con TextAreas
					String IDpaso = "";
					String IDNombre = "";
					String IDPrecio = "";
					String IDCantidad = "";
					for (int j = 1; j<ArrMat.length; j++) {
						if(ArrMat[j].getID() !=0) {
						IDpaso = IDpaso + ArrMat[j].getID() + " \n";
						IDL.setText(IDpaso);
						
						IDNombre = IDNombre + ArrMat[j].getNombre() + " \n";
						NombreL.setText(IDNombre);
						
						IDPrecio = IDPrecio + ArrMat[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecio);
						
						IDCantidad = IDCantidad + ArrMat[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidad);
						}
						
					}		
					
					
					//Se guardan cambios
					GuardarCambios = new JButton ("ELIMINAR MATERIAL");
					GuardarCambios.addActionListener(new ActionListener()
					{
					public void actionPerformed(ActionEvent event)
					{
						IDARR = Integer.parseInt(IDText.getText());
						//Se revisa si existe el ID
						if (IDARR >= ArrMat.length) {
							JFrame Pedidos = new JFrame();
							Pedidos.setSize(600, 300);
							Pedidos.setTitle("Revisar");
							
							Toolkit tool=Pedidos.getToolkit();
							Dimension size= tool.getScreenSize();
							
							Pedidos.setLocation(size.width/2- Pedidos.getWidth()/2 +50, size.height/2 - Pedidos.getHeight()/2);
							GridBagConstraints c =new GridBagConstraints();
							JPanel display=new JPanel();
							display.setLayout(new GridBagLayout());
							Pedidos.getContentPane().add(display);
											
							JPanel botones =  new JPanel();
							botones.setLayout(new GridBagLayout());
							Border border = BorderFactory.createLineBorder(Color.BLACK);
							
							Scroll = new JScrollPane();
							Scroll.setBounds(200, 200, 200, 200);
							
							//Si no existe aparece este mensaje
							Text = "El ID seleccionado no existe o fue borrado, favor de revisar el dato.";
																			
							IDPedidos = new JTextArea (Text);
							c. fill = GridBagConstraints. HORIZONTAL;
							c.gridwidth = 1;
							c. gridx = 0;
							c. gridy = 0;
							botones.add(IDPedidos, c);
							
							
							
							Scroll.setViewportView(botones);

							
							Pedidos.add(Scroll);
							Pedidos.setVisible(true);
								
							
						}else {
						//Si s� existe se asignan los valores
						for(int j=0; j<ArrMat.length; j++) {
							if(ArrMat[j].getID()==IDARR) {
								ArrMat[j] = valores2;
							}
							Menu guardar = new Menu();
							try {
								//Se guarda el archivo
								guardar.GuardarArchivoMat();
							} catch (IOException e) {
							}
							
						}
						
						
						
						EliminarMaterial.setVisible(false);
						
						}
						
					} });
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 2;
					c. gridx = 0;
					c. gridy = 2;
					botones.add(GuardarCambios, c);	
				} });
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 1;
				c. gridx = 1;
				c. gridy = 3;
				panel.add(EliminarM, c);
				
				//Nuevo bot�n, lista de Productos
				ListaP = new JButton ("Lista Productos");
				ListaP.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					//Se crea un nuevo Frame y Panel
					JFrame ListaProductos = new JFrame();
					ListaProductos.setSize(600, 600);
					ListaProductos.setTitle("LISTA PRODUCTOS");
					
					Toolkit tool=ListaProductos.getToolkit();
					Dimension size= tool.getScreenSize();
					
					ListaProductos.setLocation(size.width/2- ListaProductos.getWidth()/2 +50, size.height/2 - ListaProductos.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					ListaProductos.getContentPane().add(display);
					
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					
					Scroll = new JScrollPane();
					Scroll.setBounds(200, 200, 200, 200);
								
					//Se asignan los Labels y TextAreas
					ID = new JLabel("ID", JLabel.CENTER);
					Border border = BorderFactory.createLineBorder(Color.BLACK);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 0;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 0;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 0;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 0;
					botones.add(Cantidad, c);
					
					CantidadT = new JLabel("Cantidad del Material", JLabel.CENTER);
					CantidadT.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 5;
					c. gridy = 0;
					botones.add(CantidadT, c);
					
					Tela = new JLabel("IDMaterial", JLabel.CENTER);
					Tela.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 4;
					c. gridy = 0;
					botones.add(Tela, c);
					
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 1;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 1;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 1;
					botones.add(CantidadL, c);
					
					CantidadTelaL = new JTextArea ();
					CantidadTelaL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 5;
					c. gridy = 1;
					botones.add(CantidadTelaL, c);
					
					ColorTelaL = new JTextArea ();
					ColorTelaL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 4;
					c. gridy = 1;
					botones.add(ColorTelaL, c);
					
					//Se crea la tabla como en los botones pasados
					String IDpaso = "";
					String IDNombre = "";
					String IDPrecio = "";
					String IDCantidad = "";
					String IDColorTela = "";
					String IDCantidadTela = "";
					for (int j = 1; j<ArrProd.length; j++) {
						if(ArrProd[j].getID() !=0) {
						IDpaso = IDpaso + ArrProd[j].getID() + " \n";
						IDL.setText(IDpaso);
						
						IDNombre = IDNombre + ArrProd[j].getNombre() + " \n";
						NombreL.setText(IDNombre);
						
						IDPrecio = IDPrecio + ArrProd[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecio);
						
						IDCantidad = IDCantidad + ArrProd[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidad);
						
						IDCantidadTela = IDCantidadTela + ArrProd[j].getCantidadMat() + " \n";
						CantidadTelaL.setText(IDCantidadTela);
						
						IDColorTela = IDColorTela + ArrProd[j].getIDMat() + " \n";
						ColorTelaL.setText(IDColorTela);
						}
						
					}				
					
					Scroll.setViewportView(botones);
					
					ListaProductos.add(Scroll);
					ListaProductos.setVisible(true);
					
				} });
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 1;
				c. gridx = 0;
				c. gridy = 4;
				panel.add(ListaP, c);
				
				//Nuevo bot�n, Lista de Materiales
				ListaM = new JButton ("Lista Materiales");
				ListaM.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					//Nuevo Frame y Panel
					JFrame ListaMateriales = new JFrame();
					ListaMateriales.setSize(600, 600);
					ListaMateriales.setTitle("LISTA MATERIALES");
					
					Toolkit tool=ListaMateriales.getToolkit();
					Dimension size= tool.getScreenSize();
					
					ListaMateriales.setLocation(size.width/2- ListaMateriales.getWidth()/2 +50, size.height/2 - ListaMateriales.getHeight()/2);
					GridBagConstraints c =new GridBagConstraints();
					JPanel display=new JPanel();
					display.setLayout(new GridBagLayout());
					ListaMateriales.getContentPane().add(display);
					
					JPanel botones =  new JPanel();
					botones.setLayout(new GridBagLayout());
					
					Scroll = new JScrollPane();
					Scroll.setBounds(200, 200, 200, 200);
								
					//Se asignan Labels y TextAreas
					ID = new JLabel("ID", JLabel.CENTER);
					Border border = BorderFactory.createLineBorder(Color.BLACK);
					ID.setBorder(border);
					ID.setSize(100, 100);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 0;
					botones.add(ID, c);
					
					Nombre = new JLabel("Nombre", JLabel.CENTER);
					Nombre.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 0;
					botones.add(Nombre, c);
					
					Precio = new JLabel("Precio", JLabel.CENTER);
					Precio.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 0;
					botones.add(Precio, c);
					
					Cantidad = new JLabel("Cantidad", JLabel.CENTER);
					Cantidad.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 0;
					botones.add(Cantidad, c);
					
					IDL = new JTextArea ();
					IDL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 0;
					c. gridy = 1;
					botones.add(IDL, c);
					
					NombreL = new JTextArea ();
					NombreL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 1;
					c. gridy = 1;
					botones.add(NombreL, c);
					
					PrecioL = new JTextArea ();
					PrecioL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 2;
					c. gridy = 1;
					botones.add(PrecioL, c);

					CantidadL = new JTextArea ();
					CantidadL.setBorder(border);
					c. fill = GridBagConstraints. HORIZONTAL;
					c.gridwidth = 1;
					c. gridx = 3;
					c. gridy = 1;
					botones.add(CantidadL, c);
					
					//Se hace la tabla como en los botones anteriores
					String IDpaso = "";
					String IDNombre = "";
					String IDPrecio = "";
					String IDCantidad = "";
					for (int j = 1; j<ArrMat.length; j++) {
						if(ArrMat[j].getID() !=0) {
						IDpaso = IDpaso + ArrMat[j].getID() + " \n";
						IDL.setText(IDpaso);
						
						IDNombre = IDNombre + ArrMat[j].getNombre() + " \n";
						NombreL.setText(IDNombre);
						
						IDPrecio = IDPrecio + ArrMat[j].getPrecio() + " \n";
						PrecioL.setText(IDPrecio);
						
						IDCantidad = IDCantidad + ArrMat[j].getCantidad() + " \n";
						CantidadL.setText(IDCantidad);
						}
						
					}		
					
					Scroll.setViewportView(botones);
					
					ListaMateriales.add(Scroll);
					ListaMateriales.setVisible(true);
					
				}});
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 1;
				c. gridx = 1;
				c. gridy = 4;
				panel.add(ListaM, c);
				
				
				Salir = new JButton ("Salir");
				Salir.addActionListener(new ActionListener()
				{
				public void actionPerformed(ActionEvent event)
				{
					System.exit(0);
					
				} });
				c. fill = GridBagConstraints. HORIZONTAL;
				c.gridwidth = 2;
				c. gridx = 0;
				c. gridy = 7;
				panel.add(Salir, c);
				
				
	}
	// Aqu� se le agrega un nuevo lugar para el arreglo de productos
	public static Productos[] addItem(Productos [] arr, Productos item){
		Productos [] paso = new Productos[arr.length+1];
		 for(int i =0; i<arr.length; i++){
			 paso[i] = arr[i];
		 }
		paso[paso.length-1] = item;		 
		return paso;
	}
	//Se asigna un nuevo lugar para el arreglo de materiales
	public static Materiales[] addItemMat(Materiales [] arr, Materiales item){
		Materiales [] paso = new Materiales[arr.length+1];
		 for(int i =0; i<arr.length; i++){
			 paso[i] = arr[i];
		 }
		paso[paso.length-1] = item;		 
		return paso;
	}
	
	public void GuardarArchivoProd() throws IOException{
		PrintWriter fileIn;
		fileIn=new PrintWriter(new FileWriter("ProductosToken.txt"));
		for (int i=1; i<ArrProd.length;i++)
		{

			fileIn.println(ArrProd[i].Tokenizer());
		}
		fileIn.close();
		
		
	}
	//Se guarda el archivo de Materiales
	public void GuardarArchivoMat()throws IOException{
		PrintWriter fileIn;
		fileIn = new PrintWriter(new FileWriter("MaterialesToken.txt"));
		for (int i = 1; i<ArrMat.length;i++) {
			
			fileIn.println(ArrMat[i].Tokenizer());
		}
		fileIn.close();
	}
	
//Se guarda el archivo de productos
	public void GuardarArchivo() throws IOException{
		PrintWriter fileIn;
		fileIn=new PrintWriter(new FileWriter("ProductosToken.txt"));
		for (int i=1; i<ArrProd.length;i++)
		{

			fileIn.println(ArrProd[i].Tokenizer());
		}
		fileIn.close();
		
		fileIn = new PrintWriter(new FileWriter("MaterialesToken.txt"));
		for (int i = 1; i<ArrMat.length;i++) {
			
			fileIn.println(ArrMat[i].Tokenizer());
		}
		fileIn.close();
		
	}
	//Se lee el archivo de Productos y se guarda en el arreglo de productos
	 public void LeerArchivo () throws IOException{
		 
		 String linea, dato = null;
		 int i = 1;
		 int j=1;
		 
		 BufferedReader fileOut;
		 fileOut = new BufferedReader(new FileReader ("ProductosToken.txt"));
		 linea = fileOut.readLine();
		 while (linea != null){
			 StringTokenizer token = new StringTokenizer (linea, ",");
			 while (token.hasMoreTokens()){
				 switch (i){		 
				 case 1:
					 dato = token.nextToken();
					 IDARR = j;
					 id++;
					 break;
				 case 2:
					 dato = token.nextToken();
					 CantFin = Integer.parseInt(dato);
					 break;
				 case 3:
					 dato = token.nextToken();
					 MaterialesCant = dato;
					 break;
				 case 4:
					 dato = token.nextToken();
					 PrecioFin = Double.parseDouble(dato);
					 break;
				 case 5:
					 dato = token.nextToken();
					 NombreFin = dato;
					 break;
				 case 6:
					 dato = token.nextToken();
					 TelaFin = dato;
					 break;
				 			
					 
				 } 
				 if (i ==6){
				 i = 0;}
				 else{i++;
					 
				 }	
				 
			 }

			 Productos valores = new Productos (IDARR, CantFin, MaterialesCant, PrecioFin, NombreFin, TelaFin);
				ArrProd[0] = valores;
				ArrProd = addItem(ArrProd, valores);

				
				
			 linea = fileOut.readLine();
			 j++;
		 }
		 fileOut.close();

}
	 //Se lee el archivo de materiales y se asigna al arreglo de materiales
	 public void LeerArchivoMat () throws IOException{
		 
		 String linea, dato = null;
		 int i = 1;
		 int j=1;
		 
		 BufferedReader FileOut;
		 FileOut = new BufferedReader(new FileReader ("MaterialesToken.txt"));
		 linea = FileOut.readLine();
		 while (linea != null){
			 StringTokenizer token = new StringTokenizer (linea, ",");
			 while (token.hasMoreTokens()){
				 switch (i){		 
				 case 1:
					 dato = token.nextToken();
					 IDARR = j;
					 id++;
					 break;
				 case 2:
					 dato = token.nextToken();
					 NombreFin = dato;
					 break;
				 case 3:
					 dato = token.nextToken();
					 CantMatFin = Double.parseDouble(dato);
					 break;
				 case 4:
					 dato = token.nextToken();
					 PrecioFin = Double.parseDouble(dato);
					 break;
				 } 
				 if (i ==4){
				 i = 0;}
				 else{i++;
					 
				 }	
				 
			 }

			 Materiales valores = new Materiales (IDARR, NombreFin, CantMatFin, PrecioFin);
				ArrMat[0] = valores;
				ArrMat = addItemMat(ArrMat, valores);
				
				
			 linea = FileOut.readLine();
			 j++;
		 }
		 

		 FileOut.close();
	 }
}
