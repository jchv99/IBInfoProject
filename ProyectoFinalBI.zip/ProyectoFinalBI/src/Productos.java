public class Productos {
	
	private int cantidad, ID;
	private double Precio;
	private String Nombre, CantidadMat, IDMateriales;
	
	//Se hace un constructor vac�o para eliminar productos
	Productos(){
		ID = this.getID();
		cantidad = 0;
		IDMateriales = " ";
		Precio = 0.0;
		Nombre = " ";
		
	}
	//Se hace un constructor con variables para asignar valores a cada espacio del Array
	Productos(int miID, int miCantidad, String misCantidadesMat, double miPrecio, String miNombre, String misIDMat){
		
		ID= miID;
		cantidad = miCantidad;
		IDMateriales = misIDMat;
		Precio = miPrecio;
		Nombre = miNombre;
		CantidadMat = misCantidadesMat;
		
		
	}
	//Se asigna la cantidad de material del espacio del arreglo
	public void setCantidadMat (String misCantidadesMat) {
		CantidadMat = misCantidadesMat;
	}
	//Se devuelve la cantidad de material del espacio del arreglo
	public String getCantidadMat() {
		return CantidadMat;
	}
	//Se asigna la cantidad de producto del espacio del arreglo
	public void setCantidad(int miCantidad) {
		if(miCantidad >=0) {
			cantidad = miCantidad;
		}
		
	}
	//Se devuelve la cantidad de producto del espacio del arreglo
	public int getCantidad() {
		return cantidad;
	}
	//Se asigna el ID del material usado en el producto del espacio del arreglo
	public void setIDMat(String misIDMat) {
		IDMateriales = misIDMat;
	}
	//Se devuelve el ID del material usado en el producto del espacio del arreglo
	public String getIDMat() {
		return IDMateriales;
	}
	//Se asigna el precio del producto del espacio del arreglo
	public void setPrecio(double miPrecio) {
		if (miPrecio >=0) {
			Precio = miPrecio;
		}
	}
	//Se devuelve el precio del producto del espacio del arreglo
	public double getPrecio() {
		return Precio;
	}
	//Se asigna el ID del producto del espacio del arreglo
	public void setID(int miID){
		if (miID >= 0){
			ID= miID;
		}
	}
	//Se asigna el nombre del producto del espacio del arreglo
	public void setNombre(String miNombre) {
		Nombre = miNombre;
	}
	
	//Se devuelve el nombre del producto del espacio del arreglo
	public String getNombre() {
		return Nombre;
	}
	//Se devuelve el ID del producto del espacio del arreglo
	public int getID(){
		return ID;
	}
	
	//Se hace el Token para guardarlo en el archivo de Productos y sea m�s f�cil leerlo en un futuro
	public String Tokenizer(){
		return (this.getID() + "," + this.getCantidad() + "," + this.getCantidadMat() + "," 
	+ this.getPrecio() + "," + this.getNombre() + "," + this.getIDMat());
	}

}
